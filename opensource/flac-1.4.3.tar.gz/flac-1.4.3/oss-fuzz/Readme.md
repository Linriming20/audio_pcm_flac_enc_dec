Fuzzers fuzzer_decoder.cc and fuzzer_encoder.cc were taken from

    https://github.com/guidovranken/flac-fuzzers

The header files in the directory fuzzing and below were taken from:

    https://github.com/guidovranken/fuzzing-headers.git

Some minor modifications were made to make them build with the default C++
warning flags.

The code mentioned above, contributed by Guido Vranken, is licensed under
the MIT license. See the files themselves for details
